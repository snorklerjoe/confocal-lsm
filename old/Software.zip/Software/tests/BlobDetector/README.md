Please see the following [blog post](https://www.learnopencv.com/blob-detection-using-opencv-python-c/) for more details about this code

[Blob Detection Using OpenCV ( Python, C++ )](https://www.learnopencv.com/blob-detection-using-opencv-python-c/)


# AI Courses by OpenCV

Want to become an expert in AI? [AI Courses by OpenCV](https://opencv.org/courses/) is a great place to start. 

<a href="https://opencv.org/courses/">
<p align="center"> 
<img src="https://www.learnopencv.com/wp-content/uploads/2020/04/AI-Courses-By-OpenCV-Github.png">
</p>
</a>
